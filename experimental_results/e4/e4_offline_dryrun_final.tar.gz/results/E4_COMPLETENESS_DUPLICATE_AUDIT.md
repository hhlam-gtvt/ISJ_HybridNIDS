# E4 Completeness and Duplicate-Impact Audit

## Run identity

- Runner: `E4-OFFLINE-DRYRUN-v1.0`
- RQ3 policy freeze: `E4-RQ3-POLICY-FREEZE-v1.0`
- Frozen action matrix: `E4-ACTION-MATRIX-v1.0`
- Main execution mode: **DRY_RUN** (no host/container firewall command is executed by this runner).

## Real-evidence corpus used

The E4 baseline uses **15 confirmed E1 Test incidents** and preserves their E1 `event_id`, `session_id`, source/destination addresses, reason code, corroboration type, evidence inventory and artifact hashes. Scenario distribution: `{"brute_force": 3, "dos": 3, "exploit": 3, "normal": 3, "scan": 3}`. The 15 Test incidents contribute **78 evidence rows** in the provided E1 event manifest.

Controlled fault injection changes only the field under test (for example: missing IP, whitelist conflict, shared/NAT flag, critical-asset flag, degraded provenance, approval token, or injection string) while keeping the source E1 incident reference.

## E4 coverage checklist

| Requirement | Evidence generated | Status |
|---|---|---|
| Real normalized evidence | 15 E1 Test incidents | PASS |
| Duplicate delivery | `E4-DUP-01`, duplicate_suppressed_count=2 | PASS |
| Malformed/missing fields | 3 malformed cases | PASS |
| Retry count | `E4-RETRY-01` + `FR-RETRY-01` | PASS |
| Restart at declared crash points | 6 crash points in failure/recovery CSV | PASS (state-machine dry-run) |
| Whitelist conflict | `E4-WHITELIST-01` | PASS |
| NAT/shared address | `E4-NAT-01` | PASS |
| Critical asset | `E4-CRITICAL-01` | PASS |
| Expired/forged approval | 2 negative approval cases + 1 valid case | PASS |
| Prompt injection | `E4-INJECT-PROMPT` | PASS for action-authority isolation |
| Retrieved-record injection | `E4-INJECT-RETRIEVED` | PASS for action-authority isolation |
| Queue exhaustion | `FR-QUEUE-01` | PASS (durable/backpressure model) |
| Time-bounded action | `FR-TTL-01` | PASS |
| Rollback | `FR-ROLLBACK-01` | PASS |
| Firewall reconciliation | DB-only and live-only mismatch cases | PASS (adapter/state model) |
| RQ3 blind vs aware | 30 paired rows | PASS |

## Duplicate impact audit

- Duplicate case deliveries: 3
- Unique action intent: 1
- Suppressed duplicate deliveries: 2
- Duplicate external effects: 0
- Idempotency basis: stable `(source_event_id, policy_mode, action)` key and stable `action_id`.

## Acceptance criterion audit

- High-impact rows with a non-NONE effect in this package: **1**. These are **simulated adapter effects only**, not OS/network effects.
- High-impact simulated effects without valid approval: **0**.
- Effect rows missing action ID / TTL / observed state / recovery result: **0**.
- Overall dry-run acceptance result: **PASS**.

## RQ3 control audit

Both policies receive the same incident identity and frozen action matrix. The provenance-blind policy is prohibited from using detector/provenance/evidence-quality fields. The provenance-aware policy can use those fields, but neither policy is allowed to alter the frozen action matrix. Across 30 paired rows (15 real + 15 degraded-provenance variants), action divergence count is **9**. Divergence is expected only where provenance degradation causes the aware policy to withhold a HIGH-impact action.

## Interpretation boundary

This package establishes a reproducible **offline E4 dry-run** using the evidence manifests supplied in this conversation. It does **not** claim that Linux/Docker iptables was changed, that a physical NAT gateway was exercised, or that a real firewall rule was reconciled. For the final thesis claim about live enforcement/reconciliation, run the cloud checklist against the actual orchestrator and replace the adapter-level recovery observations with exported live logs.
